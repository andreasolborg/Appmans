package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;










public class MainController {
	
	@FXML
	private AnchorPane rootPane;
		
	@FXML
	public void openGradesWindow(ActionEvent event) throws IOException {
		AnchorPane pane = FXMLLoader.load(getClass().getResource("gradesFXML.fxml"));
		rootPane.getChildren().setAll(pane);
	}
	
		
	public void openHomeWindow1(ActionEvent event) throws IOException {
		AnchorPane pane = FXMLLoader.load(getClass().getResource("main.fxml"));
		rootPane.getChildren().setAll(pane);
		
	}
	

	public void openHomeWindow(ActionEvent Event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("main.fxml"));
			Scene mainScene = new Scene(root);
			Stage homeStage = new Stage();
			homeStage.setTitle("The app");
			homeStage.setScene(mainScene);
			homeStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void openAvgWindow(ActionEvent event) {
	
	}
}
